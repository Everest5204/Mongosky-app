package com.mongosky.app.domain.model.profile

import com.mongosky.app.domain.model.FeedAuthor

data class OwnProfile(
    val id: String,
    val firstName: String,
    val lastName: String,
    val bio: String = "",
    val profileImageUrl: String? = null,
    val coverImageUrl: String? = null,
    val followersCount: Long = 0,
    val followingCount: Long = 0,
    val postsCount: Long = 0
) {
    val displayName: String get() = "$firstName $lastName".trim()
    val author: FeedAuthor get() = FeedAuthor(id, firstName, lastName, profileImageUrl)
}

enum class OwnProfileTab(val label: String) { ALL("All"), PHOTOS("Photos"), VIDEOS("Videos") }
enum class ProfileImageKind(val endpoint: String, val field: String, val maxEdge: Int) {
    AVATAR("profile-image", "profile_image", 1600),
    COVER("cover-image", "cover_image", 2400)
}

/** Media responses are partial; an empty unrelated image field must not erase it. */
data class ProfileMediaChange(val ownerId: String, val kind: ProfileImageKind, val imageUrl: String)
data class ProfileChanged(val ownerId: String, val version: Long, val mediaChanged: Boolean)

object ProfileBio {
    const val MAX_LENGTH = 100
    fun normalize(text: String): String = text.replace("\r\n", "\n").replace('\r', '\n').trim()
    fun count(text: String): Int = text.codePointCount(0, text.length)
    fun limit(text: String): String = if (count(text) <= MAX_LENGTH) text else
        text.substring(0, text.offsetByCodePoints(0, MAX_LENGTH))
}

enum class ProfileConnectionKind(val path: String, val label: String) {
    FOLLOWERS("followers", "Followers"), FOLLOWING("following", "Following")
}
data class ProfileConnection(
    val id: String,
    val firstName: String,
    val lastName: String,
    val imageUrl: String?,
    val isFollowing: Boolean,
    val followsYou: Boolean,
    val isSelf: Boolean
) {
    val displayName: String get() = "$firstName $lastName".trim()
}
data class ProfileConnectionPage(
    val items: List<ProfileConnection>, val nextCursor: String?, val hasMore: Boolean
)

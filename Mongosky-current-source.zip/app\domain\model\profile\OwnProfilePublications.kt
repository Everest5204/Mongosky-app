package com.mongosky.app.domain.model.profile

import com.mongosky.app.domain.model.FeedMediaType
import com.mongosky.app.domain.model.FeedPost
import com.mongosky.app.domain.model.FeedPostType
import com.mongosky.app.domain.model.FeedSource
import com.mongosky.app.domain.model.mediapost.MediaPost
import com.mongosky.app.domain.model.mediapost.MediaPostType
import com.mongosky.app.domain.model.textpost.TextPost

/** Converts only successful, owned creation results, never an upload draft. */
internal fun MediaPost.toOwnProfilePost(): FeedPost? {
    if (!isSelf || media.isEmpty()) return null
    val postType = when (type) {
        MediaPostType.IMAGE -> FeedPostType.IMAGE
        MediaPostType.VIDEO -> FeedPostType.VIDEO
        else -> return null
    }
    val mediaType = if (type == MediaPostType.IMAGE) FeedMediaType.IMAGE else FeedMediaType.VIDEO
    if (media.any { it.type != mediaType }) return null
    return FeedPost(id = id, userId = userId, author = author, source = FeedSource.MEDIA, type = postType,
        createdAt = createdAt, updatedAt = updatedAt, caption = caption, media = media,
        likesCount = likesCount, commentsCount = commentsCount, sharesCount = sharesCount,
        isSelf = true, isFollowing = false)
}

internal fun TextPost.toOwnProfilePost(): FeedPost? {
    if (!isSelf || displayText.isBlank()) return null
    return FeedPost(id = id, userId = userId, author = author, source = FeedSource.TEXT, type = FeedPostType.TEXT,
        createdAt = createdAt, updatedAt = updatedAt, text = text, caption = caption,
        textBackground = textBackground, textColor = textColor, textStyle = textStyle,
        likesCount = likesCount, commentsCount = commentsCount, sharesCount = sharesCount,
        isSelf = true, isFollowing = false)
}

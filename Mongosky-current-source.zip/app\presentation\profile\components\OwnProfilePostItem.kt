package com.mongosky.app.presentation.profile.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.mongosky.app.domain.model.*
import com.mongosky.app.domain.model.feed.ReactionSummary
import com.mongosky.app.domain.model.mediapost.MediaPost
import com.mongosky.app.domain.model.mediapost.MediaPostType
import com.mongosky.app.domain.model.profile.OwnProfile
import com.mongosky.app.domain.model.profile.ProfileGalleryAsset
import com.mongosky.app.domain.model.textpost.TextPost
import com.mongosky.app.presentation.home.*
import com.mongosky.app.presentation.home.cards.*
import java.time.Instant

@Composable
internal fun OwnProfilePostItem(
    raw: FeedPost, owner: OwnProfile?, now: Instant, actionsModel: HomeFeedViewModel,
    enabled: Boolean, onPhotos: (List<FeedMedia>, Int) -> Unit, onVideo: (ProfileGalleryAsset) -> Unit,
    onCopy: (HomePost) -> Unit, onShare: (HomePost) -> Unit
) {
    val post = remember(raw, owner) { raw.toHomePost(owner?.author ?: raw.author) }
    LaunchedEffect(post.key, actionsModel.uiState.refreshVersion) { actionsModel.ensureReaction(post) }
    val reaction = actionsModel.reactions[post.key] ?: PostReactionState(ReactionSummary(total = post.likesCount))
    val comments = actionsModel.commentCounts[post.key] ?: post.commentsCount
    val actions = PostCardActions(onReact = { actionsModel.react(post, it) }, onComments = { actionsModel.openComments(post) },
        onShare = { onShare(post) }, onCopyLink = { onCopy(post) }, onReactionPeople = { actionsModel.openReactionPeople(post) },
        onRetryReaction = { actionsModel.ensureReaction(post) })
    when (post) {
        is HomePost.Text -> TextPostCard(post.post, now, reaction, comments, enabled, actions)
        is HomePost.Media -> {
            val video = remember(post) { post.post.media.firstOrNull { it.type == FeedMediaType.VIDEO } }
            if (video == null) MediaPostCard(post.post, now, reaction, comments, enabled, actions, onPhotos)
            else Column(Modifier.fillMaxWidth().background(Color.White)) {
                PostHeader(post.author, post.createdAt, now, actions)
                PostCaption(post.post.caption)
                val asset = remember(video, post) { ProfileGalleryAsset(post.key, post.id, video, post.post.caption) }
                ProfileGalleryTile(asset, { onVideo(asset) }, Modifier.fillMaxWidth().height(430.dp))
                PostFooter(reaction, comments, enabled, actions)
            }
        }
    }
    FeedDivider()
}

private fun FeedPost.toHomePost(author: FeedAuthor): HomePost = if (source == FeedSource.TEXT) {
    HomePost.Text(TextPost(id, userId, author, createdAt, updatedAt, text, caption, textBackground, textColor, textStyle,
        likesCount, commentsCount, sharesCount, isSelf = true))
} else {
    val mediaType = when (type) {
        FeedPostType.IMAGE -> MediaPostType.IMAGE
        FeedPostType.VIDEO -> MediaPostType.VIDEO
        FeedPostType.PROFILE_PHOTO_UPDATE -> MediaPostType.PROFILE_PHOTO_UPDATE
        FeedPostType.COVER_PHOTO_UPDATE -> MediaPostType.COVER_PHOTO_UPDATE
        else -> MediaPostType.UNKNOWN
    }
    HomePost.Media(MediaPost(id, userId, author, createdAt, updatedAt, mediaType, caption, media,
        likesCount, commentsCount, sharesCount, isSelf = true))
}

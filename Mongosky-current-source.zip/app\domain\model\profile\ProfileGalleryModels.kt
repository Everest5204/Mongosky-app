package com.mongosky.app.domain.model.profile

import com.mongosky.app.domain.model.FeedMedia
import com.mongosky.app.domain.model.FeedMediaType
import com.mongosky.app.domain.model.FeedPost
import java.net.URI

data class ProfileGalleryAsset(val key: String, val postId: String, val media: FeedMedia, val caption: String) {
    val thumbnail: String? get() = profileThumbnail(media.url, media.type)
}

fun profileGallery(posts: List<FeedPost>, type: FeedMediaType): List<ProfileGalleryAsset> = posts.flatMap { post ->
    post.media.filter { it.type == type }.sortedBy { it.order }.mapIndexed { index, media ->
        ProfileGalleryAsset("${post.source}:${post.id}:${media.id ?: index}:$type", post.id, media, post.caption)
    }
}

/** Small Cloudinary derivatives; other providers and signed links stay usable. */
fun profileThumbnail(url: String, type: FeedMediaType): String? {
    val uri = runCatching { URI(url) }.getOrNull() ?: return if (type == FeedMediaType.IMAGE) url else null
    if (uri.host != "res.cloudinary.com" || uri.scheme != "https") return if (type == FeedMediaType.IMAGE) url else null
    val segment = if (type == FeedMediaType.VIDEO) "/video/upload/" else "/image/upload/"
    val at = url.indexOf(segment)
    if (at < 0) return if (type == FeedMediaType.IMAGE) url else null
    val prefix = url.substring(0, at + segment.length)
    val asset = url.substring(at + segment.length)
    if (asset.startsWith("s--")) return if (type == FeedMediaType.IMAGE) url else null
    if (type == FeedMediaType.IMAGE) return prefix + "f_auto,q_auto:eco,c_limit,w_600/" + asset
    val path = asset.substringBefore('?')
    val dot = path.lastIndexOf('.')
    if (dot <= path.lastIndexOf('/')) return null
    return prefix + "so_auto,c_fill,g_auto,w_480,h_854,f_auto,q_auto/" + path.substring(0, dot) + ".jpg"
}
